import React from 'react'
import { Route, Routes } from 'react-router-dom'
import HomePage from './pages/HomePage'
import ProfilePage from './pages/ProfilePage'
import LoginPage from './pages/LoginPage'
import Signup from './pages/Signup'
import Landingpage from './pages/Landingpage'
const App = () => {
  return (
    <div className=" ">
      
      <Routes>
        <Route path='/' element = {<Landingpage/>}/>
        <Route path='/home' element = {<HomePage/>}/>
        <Route path='/login' element = {<LoginPage/>}/>
        <Route path='/profile' element = {<ProfilePage/>}/>
        <Route path='/signup' element = {<Signup/>}/>
      </Routes>
    </div>
  )
}

export default App
