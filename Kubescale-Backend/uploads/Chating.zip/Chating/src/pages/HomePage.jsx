import React, { useState } from 'react'
import Sidebar from '../components/Sidebar'
import ChatContainer from '../components/ChatContainer'
import RightSideBar from '../components/RightSideBar'


const HomePage = () => {
  const[selectedUser, setSelectedUser] = useState(false)
  return (
    <div className="border w-full h-screen sm:px-[15%] sm:py-[5%] bg-[url('./src/assets/bgImage.svg')]  bg-center bg-cover text-white  bg-contain  ">
      <div className={`backdrop-blur-xl border-2 border-gray-600 rounded-2xl h-full overflow-hidden grid 
      grid-cols-1 relative ${selectedUser ? 'md:grid-cols-[1fr_1.5fr] xl:grid-cols-[1fr_2fr]'
      :'grid-cols-1 md:grid-cols-2'}`}>
      <Sidebar selectedUser = {selectedUser} setSelectedUser ={setSelectedUser}/>
      <ChatContainer selectedUser = {selectedUser} setSelectedUser ={setSelectedUser}/>
      {/* <RightSideBar selectedUser = {selectedUser} setSelectedUser ={setSelectedUser}/> */}
    </div>
    </div>
  )
}

export default HomePage
