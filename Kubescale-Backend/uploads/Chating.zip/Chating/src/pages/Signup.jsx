import React from 'react'
import { Link } from 'react-router-dom'

const Signup = () => {
  return (
    <div className="h-screen text-white bg-[url('./src/assets/bgImage.svg')]  bg-center ">
      <div className='relative flex justify-center items-center h-screen'>
        <div className=' relative border border-gray-500 w-100 h-auto p-7 backdrop-blur-lg rounded-2xl '>
          <p className='flex justify-center items-center mb-5 mt-3 text-3xl '>Sign up</p>
          <form action="" className=' flex flex-col'>
          <input
              type="text"
              placeholder="Name"
              name="name"
              className='border border-gray-400 p-1 pl-5 rounded-xl mb-4 ' />
            <input
              type="text"
              placeholder="Username"
              name="username"
              className='border border-gray-400 p-1 pl-5 rounded-xl ' />

            <input
              type="password"
              placeholder="Password"
              name="password" className='border border-gray-400 p-1 pl-5 rounded-xl my-4' />

<input
              type="password"
              placeholder="Re-enter password"
              name="password" className='border border-gray-400 p-1 pl-5 rounded-xl mb-4' />


            <button className='bg-red-700 rounded-xl mt-2 p-1 flex justify-center '>Sign up</button>

            <Link to="/login" className='flex justify-center'>
            
            <button type="button" className='m-3 cursor-pointer'><span className=' justify-center'>Already have a account ? </span> <span className='text-red-700'>Login </span></button>
            </Link>
            <p className='flex justify-center cursor-pointer'>Need Help?</p>

          </form>
        </div>
      </div>
    </div>
  )
}

export default Signup
