import React from 'react'

const ProfilePage = () => {
  return (
    <div>
      Profile Page 
    </div>
  )
}

export default ProfilePage
