import React from 'react'
import { Link } from 'react-router-dom'

const LoginPage = () => {
  return (
    <div className="h-screen text-white bg-[url('./src/assets/bgImage.svg')]  bg-center">
      <div className='relative flex justify-center items-center h-screen'>
        <div className=' relative border border-gray-500 w-100 h-auto p-7 backdrop-blur-lg rounded-2xl '>
          <p className='flex justify-center items-center mb-5 mt-3 text-3xl '>Log in</p>
          <form action="" className=' flex flex-col'>
            <input
              type="email"
              placeholder="Email"
              name="email"
              className='border border-gray-400 p-1 pl-5 rounded-xl ' />

            <input
              type="password"
              placeholder="Password"
              name="password" className='border border-gray-400 p-1 pl-5 rounded-xl my-4' />
              <Link to="/home">

            <button className='bg-red-700 rounded-xl mt-2 p-1 flex justify-center w-full '>Sign In</button>
            </Link>
            <Link to="/signup" className='flex justify-center'>
            
            <button type="button" className='m-3'><span className=' justify-center'>Don't have a acount ? </span> <span className='text-red-700'>Signup </span></button>
            </Link>
            <p className='flex justify-center'>Need Help?</p>

          </form>
        </div>
      </div>
    </div>
  )
}

export default LoginPage


/*  
<div className="">
    <form className="">
      <h1>Sign In</h1>
      <input
        type="email"
        placeholder="Email"
        name="email"
        />
      <input
        type="password"
        placeholder="Password"
        name="password"
        
        />
      <button >Sign In</button>
      <div className="form_help">
        <Link to="/signup">
          <button type="button"><h3>Don't have a acount ? </h3></button>
        </Link>
        <p>Need Help?</p>
      </div> 
    </form>
  </div>

*/