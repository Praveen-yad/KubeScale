import React from 'react'
import landing_img from '../assets/landing_img.png'
import { Link } from 'react-router-dom'
const Landingpage = () => {
  return (
    <div className="bg-[url('./src/assets/bgImage.svg')]  bg-center h-screen flex justify-center items-center text-white">
        <div className=' py-10 h-[70%] max-xl:w-[70%] max-md:h-[70%] w-[70%] max-md:gap-10 max-md:w-[70%] md:flex-row md:justify-between backdrop-blur-xl border  border-gray-500 p-10 flex flex-col justify-center items-center rounded-2xl shadow-lg'>
            <div className='flex flex-col justify-center items-center '>
                <img src={landing_img} alt="" className='max-md:w-92 md:w-100'/>
                <p className='text-2xl max-md:text-xl'>Chat anytime,anywhere</p>
            </div>
            <div className='md:w-[40%] p-10 rounded-2xl  bg-[#282142]/30 flex flex-col [word-spacing:0.3rem] justify-center text-xl '>
               <p className='pb-10'>Connect instantly with friends, family, and colleagues.
               Stay in touch anytime, anywhere — simple, secure, and fast</p> 
               <Link to="/login">
               <button className='bg-blue-500 px-10 py-2 rounded-3xl'>Start Chatting</button> </Link>
            </div>

        </div>
    </div>
  )
}

export default Landingpage
