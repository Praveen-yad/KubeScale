import React from 'react'

const RightSideBar = () => {
  return (
    <div>
      right side bar
    </div>
  )
}

export default RightSideBar
