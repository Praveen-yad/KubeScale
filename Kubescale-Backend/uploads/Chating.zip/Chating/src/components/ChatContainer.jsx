import React from 'react'
import assets from '../assets/assets'

const ChatContainer = ({ selectedUser, setSelectedUser }) => {
  return selectedUser ? (
    <div className='h-full overflow-scroll relative [scrollbar-color:transparent_transparent] 
                [&::-webkit-scrollbar]:w-2 [&::-webkit-scrollbar-track]:bg-transparent 
                [&::-webkit-scrollbar-thumb]:bg-transparent '>
                  {/* -------------header---------- */}
      <div className='flex items-center gap-3 py-3 mx-4 border-b border-stone-500'>
        <img src={selectedUser?.profilePic} alt="" className='rounded-full w-[50px]' />
        <p className='flex-1 text-lg text-white flex items-center gap-2'>{selectedUser?.fullName}
          <span className='w-2 h-2 bg-green-500 rounded-full'></span>
        </p>
        <img onClick={() => setSelectedUser(null)} src={assets.arrow_icon} alt="" className='md:hidden max-w-7' />
        <img src={assets.help_icon} alt="" className='max-md:hidden max-w-5' />
      </div>
                    {/* ------------Chat Area---------- */}




    </div>
  ) : (
    <div className="h-full w-full flex flex-col justify-center items-center text-gray-500">
      <img src={assets.logo_icon} alt="" className='max-w-16' />
      <span className='text-lg font-medium'>Chat anytime, anywhere</span>
    </div>
  )

}

export default ChatContainer
