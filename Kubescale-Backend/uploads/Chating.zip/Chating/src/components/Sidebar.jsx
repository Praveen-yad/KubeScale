import React from 'react'
import assets, { userDummyData } from '../assets/assets'
import { useNavigate } from 'react-router-dom'
import search_icon from '../assets/search_icon.png'

const Sidebar = ({selectedUser,setSelectedUser}) => {
    const navigate = useNavigate();
    return (
        <div className={`p-5 bg-[#8185b2]/10 h-screen  flex flex-col rounded-r-xl ${selectedUser ? 'max-md:hidden' : ''}`}>
            <div className='pb-5 shrink-0'>
                <div className='flex justify-between items-center'>
                    <img src={assets.logo} alt="Menu" className='max-w-40' />
                    <div className='relative py-2 group'>
                        <img src={assets.menu_icon} alt="Menu" className='max-h-5 cursor-pointer'/>
                    
                    <div className='absolute top-full right-0 z-20 w-29 p-4 rounded-md bg-[#282142] border border-gray-600
                         text-gray-100 hidden group-hover:block '>
                        <p onClick={()=> navigate('/profile')} className='cursor-pointer text-sm'>Edit Profile</p>
                        <hr className='my-2 border-t border-gray-600' />
                        <p className=''>Logout</p>
                    </div>
                    </div>
                </div>
                <div className='flex bg-[#282142] rounded-full gap-2 py-2 px-4 mt-5'>
                    <img src={search_icon} alt="search" className='w-6'/>
                    <input type="text" className="bg-transparent' text-white flex-1 placeholder:text-gray-500 "
                     placeholder='Search User...' />

                </div>

            </div>

            <div className="flex-1 overflow-y-auto min-h-0 max-h-full 
                [scrollbar-color:transparent_transparent] 
                [&::-webkit-scrollbar]:w-2 
                [&::-webkit-scrollbar-track]:bg-transparent 
                [&::-webkit-scrollbar-thumb]:bg-transparent">
            {userDummyData.map((user,index)=>
                <div onClick={()=>{setSelectedUser(user)}}
                 key={index} className= {`relative flex gap-2 p-2 pl-4 items-center rounded cursor-pointer max-sm:text-sm 
                 ${selectedUser?._id === user._id ? 'bg-[#282142]/50' : ''}`}>
                <img src={user.profilePic || assets.avatar_icon} alt="user" className='rounded-full w-[50px] aspect-[1/1]'  />
                <div>
                    <p>{user.fullName}</p>
                    {
                        index <3 ? <span className='text-green-400  text-xs' > Online</span>:<span className='text-gray-600 text-xs'>Offline</span>
                    }

                </div>
            </div>
           
            )}
            </div>

        </div>
    )
}

export default Sidebar
